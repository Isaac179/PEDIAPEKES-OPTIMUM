<div class="testimonial-section container-fluid no-left-padding no-right-padding">
  <!-- Container -->
  <div class="container">
    <!-- Section Header -->
    <div class="section-header">
      <h3>Testimonios</h3>
    </div><!-- Section Header /- -->
  </div>
  <div class="testimonial-slider">
    <div class="testimonial-box">
      <div class="testimonial-content">
        <i><img src="assets/images/testi-1.png" alt="testimonial"/></i>
        <h5>Juan pablo Noriega</h5>
        <p>Para los miembros de mi familia la experiencia de atención medica en “Pediapekes” fue realmente gratificante recomiendo sus servicios ampliamente.
</p>
      </div>
    </div>
    <div class="testimonial-box">
      <div class="testimonial-content">
        <i><img src="assets/images/testi-1.png" alt="testimonial"/></i>
        <h5>Juan pablo Noriega</h5>
        <p>Para los miembros de mi familia la experiencia de atención medica en “Pediapekes” fue realmente gratificante recomiendo sus servicios ampliamente.
</p>
      </div>
    </div>
    <div class="testimonial-box">
      <div class="testimonial-content">
        <i><img src="assets/images/testi-1.png" alt="testimonial"/></i>
        <h5>Juan pablo Noriega</h5>
        <p>Para los miembros de mi familia la experiencia de atención medica en “Pediapekes” fue realmente gratificante recomiendo sus servicios ampliamente.
</p>
      </div>
    </div>
    <div class="testimonial-box">
      <div class="testimonial-content">
        <i><img src="assets/images/testi-1.png" alt="testimonial"/></i>
        <h5>Juan pablo Noriega</h5>
        <p>Para los miembros de mi familia la experiencia de atención medica en “Pediapekes” fue realmente gratificante recomiendo sus servicios ampliamente.
</p>
      </div>
    </div>
    <div class="testimonial-box">
      <div class="testimonial-content">
        <i><img src="assets/images/testi-1.png" alt="testimonial"/></i>
        <h5>Juan pablo Noriega</h5>
        <p>Para los miembros de mi familia la experiencia de atención medica en “Pediapekes” fue realmente gratificante recomiendo sus servicios ampliamente.
</p>
      </div>
    </div>
  </div>
</div>
